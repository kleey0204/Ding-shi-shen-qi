package com.example.autoclickerpro

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("autoclicker", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("task_active", false)) return
        val service = Intent(context, FloatingService::class.java).setAction(FloatingService.ACTION_FIRE)
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service) else context.startService(service)
    }
}

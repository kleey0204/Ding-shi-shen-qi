package com.example.autoclickerpro

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object AlarmScheduler {
    private fun pending(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context, 8001, Intent(context, AlarmReceiver::class.java).setAction("com.example.autoclickerpro.ALARM"),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    fun schedule(context: Context, at: Long) {
        context.getSharedPreferences("autoclicker", Context.MODE_PRIVATE).edit().putBoolean("task_active", true).putLong("scheduled_at", at).apply()
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(context))
        else alarm.setExact(AlarmManager.RTC_WAKEUP, at, pending(context))
    }
    fun cancel(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pending(context))
    }
}

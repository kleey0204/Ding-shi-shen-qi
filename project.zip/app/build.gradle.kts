plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.autoclickerpro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.autoclickerpro"
        minSdk = 26
        targetSdk = 32
        versionCode = 14
        versionName = "8.1.8"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

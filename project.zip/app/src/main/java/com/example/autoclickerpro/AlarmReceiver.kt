package com.example.autoclickerpro

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    companion object { const val EXTRA_TASK_ID = "task_id" }

    override fun onReceive(context: Context, intent: Intent?) {
        val id = intent?.getLongExtra(EXTRA_TASK_ID, -1L) ?: -1L
        if (id <= 0L) return
        val task = TaskStore.all(context).firstOrNull {
            it.id == id && it.status == TapTask.STATUS_PENDING
        } ?: return
        val service = Intent(context, FloatingService::class.java)
            .setAction(FloatingService.ACTION_FIRE)
            .putExtra(EXTRA_TASK_ID, task.id)
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service)
        else context.startService(service)
    }
}

package com.example.autoclickerpro

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build

object AlarmScheduler {
    private fun pending(context: Context, id: Long): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java)
            .setAction("com.example.autoclickerpro.ALARM")
            .setData(Uri.parse("autotap://task/$id"))
            .putExtra(AlarmReceiver.EXTRA_TASK_ID, id)
        return PendingIntent.getBroadcast(
            context, id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context, task: TapTask) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context, task.id)
        if (Build.VERSION.SDK_INT >= 23) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.at, pi)
        } else {
            alarm.setExact(AlarmManager.RTC_WAKEUP, task.at, pi)
        }
    }

    fun cancel(context: Context, id: Long) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pending(context, id))
    }

    fun cancelAll(context: Context) {
        TaskStore.active(context).forEach { cancel(context, it.id) }
    }
}

package com.example.autoclickerpro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class TapTask(
    val id: Long,
    val at: Long,
    val status: String = STATUS_PENDING
) {
    companion object {
        const val STATUS_PENDING = "pending"
        const val STATUS_PAUSED = "paused"
        const val STATUS_DONE = "done"
        const val STATUS_FAILED = "failed"
    }
}

object TaskStore {
    private const val PREFS = "autoclicker"
    private const val KEY_TASKS = "tasks_json"

    fun all(context: Context): MutableList<TapTask> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TASKS, "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            MutableList(array.length()) { i ->
                val o = array.getJSONObject(i)
                TapTask(o.getLong("id"), o.getLong("at"), o.optString("status", TapTask.STATUS_PENDING))
            }
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    fun save(context: Context, tasks: List<TapTask>) {
        val array = JSONArray()
        tasks.forEach {
            array.put(JSONObject().put("id", it.id).put("at", it.at).put("status", it.status))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TASKS, array.toString()).apply()
    }

    fun add(context: Context, task: TapTask) {
        val tasks = all(context)
        tasks.removeAll { it.id == task.id }
        tasks.add(task)
        save(context, tasks.sortedBy { it.at })
    }

    fun updateStatus(context: Context, id: Long, status: String) {
        save(context, all(context).map { if (it.id == id) it.copy(status = status) else it })
    }

    fun updateTime(context: Context, id: Long, at: Long) {
        save(context, all(context).map { if (it.id == id) it.copy(at = at) else it }.sortedBy { it.at })
    }

    fun remove(context: Context, id: Long) {
        save(context, all(context).filterNot { it.id == id })
    }

    fun active(context: Context): List<TapTask> =
        all(context).filter { it.status == TapTask.STATUS_PENDING || it.status == TapTask.STATUS_PAUSED }

    fun clearActive(context: Context) {
        save(context, all(context).filterNot {
            it.status == TapTask.STATUS_PENDING || it.status == TapTask.STATUS_PAUSED
        })
    }
}

package com.example.autoclickerpro

import android.app.Activity
import android.app.AlarmManager
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AlarmActivity : Activity() {
    private val black = Color.rgb(0, 0, 0)
    private val white = Color.WHITE
    private val gray = Color.rgb(145, 145, 153)
    private val divider = Color.rgb(48, 48, 52)
    private lateinit var list: LinearLayout
    private lateinit var editButton: TextView
    private var editing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = black
        window.navigationBarColor = black
        window.decorView.setBackgroundColor(black)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(black)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(18))
        }
        header.addView(headerButton("‹") { finish() }, LinearLayout.LayoutParams(dp(42), dp(48)))
        header.addView(TextView(this).apply {
            text = "時間設定"
            textSize = 23f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        editButton = headerButton("編輯") { toggleEdit() }
        header.addView(editButton)
        val plus = headerButton("＋") { chooseTime(0L, true) }
        plus.textSize = 30f
        header.addView(plus, LinearLayout.LayoutParams(dp(54), dp(48)).apply { leftMargin = dp(10) })
        root.addView(header)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(26))
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun headerButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 16f
        gravity = Gravity.CENTER
        setTextColor(white)
        setPadding(dp(16), dp(8), dp(16), dp(8))
        background = GradientDrawable().apply {
            setColor(Color.rgb(43, 43, 47))
            cornerRadius = dp(30).toFloat()
        }
        setOnClickListener { action() }
    }

    private fun render() {
        list.removeAllViews()
        val section = TextView(this).apply {
            text = "其他"
            textSize = 22f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(18))
        }
        list.addView(section)
        val tasks = TaskStore.all(this).sortedBy { it.at }
        if (tasks.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "尚未建立鬧鐘\\n點擊右上角 ＋ 新增時間"
                textSize = 16f
                setTextColor(gray)
                setPadding(0, dp(28), 0, dp(28))
            })
        }
        tasks.forEach { task ->
            val enabled = task.status == TapTask.STATUS_PENDING
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(18), 0, dp(18))
            }
            val textColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val time = Calendar.getInstance().apply { timeInMillis = task.at }
            val hour = time.get(Calendar.HOUR_OF_DAY)
            val period = when {
                hour < 6 -> "凌晨"
                hour < 12 -> "上午"
                hour < 18 -> "下午"
                else -> "晚上"
            }
            val timeText = TextView(this).apply {
                text = String.format(Locale.TAIWAN, "%d:%02d", if (hour % 12 == 0) 12 else hour % 12, time.get(Calendar.MINUTE))
                textSize = 48f
                setTextColor(if (enabled) white else gray)
                includeFontPadding = false
                typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            }
            textColumn.addView(TextView(this).apply {
                text = period + "  ·  " + if (enabled) "鬧鐘已開啟" else statusLabel(task.status)
                textSize = 14f
                setTextColor(if (enabled) gray else Color.rgb(105, 105, 112))
                setPadding(0, dp(5), 0, 0)
            })
            // time is placed first, matching the native alarm list visual hierarchy
            textColumn.removeAllViews()
            textColumn.addView(timeText)
            textColumn.addView(TextView(this).apply {
                text = period + "  鬧鐘"
                textSize = 14f
                setTextColor(gray)
                setPadding(0, dp(5), 0, 0)
            })
            row.addView(textColumn, LinearLayout.LayoutParams(0, -2, 1f))
            if (editing) {
                val edit = smallAction("編輯") { chooseTime(task.at, false) { newAt -> updateTask(task, newAt) } }
                row.addView(edit)
                val delete = smallAction("刪除") { deleteTask(task) }
                row.addView(delete)
            } else {
                val toggle = Switch(this).apply {
                    isChecked = enabled
                    text = ""
                    showText = false
                    scaleX = 1.08f
                    scaleY = 1.08f
                    setOnCheckedChangeListener { _, checked -> setEnabled(task, checked) }
                }
                row.addView(toggle)
                row.setOnClickListener { chooseTime(task.at, false) { newAt -> updateTask(task, newAt) } }
            }
            list.addView(row, LinearLayout.LayoutParams(-1, -2))
            list.addView(View(this).apply { setBackgroundColor(divider) },
                LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun smallAction(label: String, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(white)
        gravity = Gravity.CENTER
        setPadding(dp(9), dp(9), dp(9), dp(9))
        setOnClickListener { action() }
    }

    private fun toggleEdit() {
        editing = !editing
        editButton.text = if (editing) "完成" else "編輯"
        render()
    }

    private fun chooseTime(initial: Long, creating: Boolean, onDone: (Long) -> Unit = { addAlarm(it) }) {
        val c = Calendar.getInstance().apply { if (initial > 0L) timeInMillis = initial }
        TimePickerDialog(this, { _, hour, minute ->
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
            }
            onDone(target.timeInMillis)
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
    }

    private fun addAlarm(at: Long) {
        if (!ensureExactAlarmPermission()) return
        val task = TapTask(System.currentTimeMillis(), at)
        TaskStore.add(this, task)
        if (getSharedPreferences("autoclicker", MODE_PRIVATE).getBoolean("automation_running", false)) {
            AlarmScheduler.schedule(this, task)
        }
        Toast.makeText(this, "鬧鐘已新增", Toast.LENGTH_SHORT).show()
        render()
    }

    private fun updateTask(task: TapTask, at: Long) {
        if (!ensureExactAlarmPermission()) return
        AlarmScheduler.cancel(this, task.id)
        val updated = task.copy(at = at, status = TapTask.STATUS_PENDING)
        TaskStore.add(this, updated)
        if (getSharedPreferences("autoclicker", MODE_PRIVATE).getBoolean("automation_running", false)) {
            AlarmScheduler.schedule(this, updated)
        }
        Toast.makeText(this, "鬧鐘時間已更新", Toast.LENGTH_SHORT).show()
        render()
    }

    private fun setEnabled(task: TapTask, enabled: Boolean) {
        if (enabled) {
            if (!ensureExactAlarmPermission()) {
                render()
                return
            }
            val nextAt = if (task.at > System.currentTimeMillis()) task.at else nextOccurrence(task.at)
            val updated = task.copy(at = nextAt, status = TapTask.STATUS_PENDING)
            TaskStore.add(this, updated)
            if (getSharedPreferences("autoclicker", MODE_PRIVATE).getBoolean("automation_running", false)) {
                AlarmScheduler.schedule(this, updated)
            }
        } else {
            AlarmScheduler.cancel(this, task.id)
            TaskStore.updateStatus(this, task.id, TapTask.STATUS_PAUSED)
        }
        render()
    }

    private fun deleteTask(task: TapTask) {
        AlarmScheduler.cancel(this, task.id)
        TaskStore.remove(this, task.id)
        render()
    }

    private fun nextOccurrence(at: Long): Long {
        val source = Calendar.getInstance().apply { timeInMillis = at }
        return Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, source.get(Calendar.HOUR_OF_DAY))
            set(Calendar.MINUTE, source.get(Calendar.MINUTE))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis
    }

    private fun ensureExactAlarmPermission(): Boolean {
        val manager = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !manager.canScheduleExactAlarms()) {
            Toast.makeText(this, "請先允許精確鬧鐘權限", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                Uri.parse("package:$packageName")))
            return false
        }
        return true
    }

    private fun statusLabel(status: String) = when (status) {
        TapTask.STATUS_DONE -> "已完成"
        TapTask.STATUS_FAILED -> "執行失敗"
        TapTask.STATUS_PAUSED -> "已關閉"
        else -> "鬧鐘"
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}

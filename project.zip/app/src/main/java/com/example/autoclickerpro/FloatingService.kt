package com.example.autoclickerpro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FloatingService : Service() {
    companion object {
        const val ACTION_SHOW = "com.example.autoclickerpro.SHOW"
        const val ACTION_PICK_POINT = "com.example.autoclickerpro.PICK_POINT"
        const val ACTION_SCHEDULE = "com.example.autoclickerpro.SCHEDULE"
        const val ACTION_FIRE = "com.example.autoclickerpro.FIRE"
        private const val CHANNEL = "scheduled_tap"
        private const val NOTIFICATION_ID = 71
    }
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var panel: View? = null
    private var picker: View? = null
    private var status: TextView? = null
    private var countdown: TextView? = null
    private var paused = false
    private var fired = false
    private var closed = false
    private var tick: Runnable? = null
    private val prefs by lazy { getSharedPreferences("autoclicker", Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification("定時神器正在等待啟動"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PICK_POINT -> showPicker()
            ACTION_SCHEDULE, ACTION_SHOW -> { closed = false; showPanel(); updateStatus() }
            ACTION_FIRE -> fireOnce()
        }
        return START_STICKY
    }

    private fun params() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 14)
            setBackgroundColor(Color.rgb(15, 22, 35))
        }
        box.addView(TextView(this).apply { text = "定時神器"; textSize = 18f; setTextColor(Color.WHITE) })
        status = TextView(this).apply { textSize = 14f; setTextColor(Color.rgb(0, 220, 190)); setPadding(0, 8, 0, 4) }
        box.addView(status)
        countdown = TextView(this).apply { textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, 8) }
        box.addView(countdown)
        addButton(box, "暫停", 0xFF34475C.toInt()) { pauseTask() }
        addButton(box, "繼續", 0xFF17634F.toInt()) { resumeTask() }
        addButton(box, "停止", 0xFF873D45.toInt()) { stopTask() }
        addButton(box, "設定", 0xFF34475C.toInt()) {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        addButton(box, "關閉", 0xFF34475C.toInt()) { closePanel() }
        panel = box
        val p = params().apply { x = 18; y = 180 }
        wm.addView(box, p)
        box.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = v.layoutParams as WindowManager.LayoutParams
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=lp.x; oy=lp.y; return false }
                    MotionEvent.ACTION_MOVE -> { lp.x=ox+(e.rawX-sx).toInt(); lp.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(v,lp); return false }
                }; return false
            }
        })
        startCountdown()
    }

    private fun addButton(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        parent.addView(Button(this).apply {
            text = label; isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE)
            setBackgroundColor(color); setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, 42).apply { topMargin = 5 })
    }

    private fun showPicker() {
        picker?.let { return }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(Color.rgb(15, 22, 35))
        }
        val marker = Button(this).apply {
            text = "⊕"; textSize = 25f; isAllCaps = false
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(0, 145, 135))
        }
        bar.addView(marker, LinearLayout.LayoutParams(64, 64))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 0, 0, 0) }
        actions.addView(TextView(this).apply {
            text = "拖曳準星到目標\n再按儲存"; textSize = 12f; setTextColor(Color.WHITE)
        })
        val save = Button(this).apply {
            text = "儲存位置"; isAllCaps = false; textSize = 12f
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(0, 135, 115))
        }
        val cancel = Button(this).apply {
            text = "取消"; isAllCaps = false; textSize = 12f
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(65, 72, 88))
        }
        actions.addView(save, LinearLayout.LayoutParams(-1, 42).apply { topMargin = 4 })
        actions.addView(cancel, LinearLayout.LayoutParams(-1, 38).apply { topMargin = 4 })
        bar.addView(actions, LinearLayout.LayoutParams(145, -2))
        picker = bar
        val lp = params().apply { x = 110; y = 300 }
        wm.addView(bar, lp)
        marker.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=lp.x; oy=lp.y; return true }
                    MotionEvent.ACTION_MOVE -> { lp.x=ox+(e.rawX-sx).toInt(); lp.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(bar, lp); return true }
                    MotionEvent.ACTION_UP -> return true
                }
                return false
            }
        })
        save.setOnClickListener {
            val x = lp.x + marker.width / 2f
            val y = lp.y + marker.height / 2f
            prefs.edit().putString("point", "${x.toInt()},${y.toInt()}").apply()
            removePicker()
            Toast.makeText(this, "已儲存點擊位置：${x.toInt()}, ${y.toInt()}", Toast.LENGTH_LONG).show()
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        cancel.setOnClickListener { removePicker() }
    }

    private fun removePicker() { picker?.let { try { wm.removeView(it) } catch (_: Exception) {} }; picker = null }

    private fun pauseTask() {
        if (fired) return
        if (paused) return
        paused = true
        AlarmScheduler.cancel(this)
        updateStatus()
    }

    private fun resumeTask() {
        if (fired || !paused) return
        val at = prefs.getLong("scheduled_at", 0L)
        val alarmManager = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
            Toast.makeText(this, "請先允許精確鬧鐘，再按繼續", Toast.LENGTH_LONG).show()
            val settings = Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(settings)
            return
        }
        if (at <= System.currentTimeMillis()) { Toast.makeText(this, "原定時間已過，請重新設定", Toast.LENGTH_SHORT).show(); return }
        paused = false
        AlarmScheduler.schedule(this, at)
        updateStatus()
    }

    private fun stopTask() {
        AlarmScheduler.cancel(this)
        prefs.edit().putBoolean("task_active", false).apply()
        handler.removeCallbacksAndMessages(null)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; closed = true
    }

    private fun fireOnce() {
        if (paused || fired || !prefs.getBoolean("task_active", true)) return
        val service = ClickAccessibilityService.instance
        val point = prefs.getString("point", null)?.split(",")
        if (service == null || point?.size != 2) {
            status?.text = "無法點擊：請確認無障礙服務與點擊位置"
            return
        }
        val x = point[0].toFloatOrNull() ?: return
        val y = point[1].toFloatOrNull() ?: return
        fired = true
        service.tap(x, y)
        prefs.edit().putBoolean("task_active", false).apply()
        status?.text = "已完成一次點擊"
        countdown?.text = "執行時間：${SimpleDateFormat("HH:mm:ss", Locale.TAIWAN).format(Date())}"
        updateNotification("已完成一次點擊")
    }

    private fun updateStatus() {
        status?.text = when { fired -> "已完成一次點擊"; paused -> "已暫停"; else -> "定時啟動中" }
        if (fired) countdown?.text = "本次任務已結束"
        updateNotification(if (paused) "定時任務已暫停" else if (fired) "已完成一次點擊" else "定時神器正在等待啟動")
    }

    private fun startCountdown() {
        tick?.let { handler.removeCallbacks(it) }
        val r = object : Runnable {
            override fun run() {
                if (panel != null && !fired) {
                    val remain = (prefs.getLong("scheduled_at", 0L) - System.currentTimeMillis()).coerceAtLeast(0L) / 1000
                    countdown?.text = if (paused) "任務暫停中" else "距離點擊：%02d:%02d:%02d".format(remain/3600, (remain%3600)/60, remain%60)
                    handler.postDelayed(this, 1000)
                }
            }
        }
        tick = r; handler.post(r)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "定時神器", NotificationManager.IMPORTANCE_LOW))
        }
    }
    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL).setContentTitle("定時神器").setContentText(text).setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(open).setOngoing(true).build()
        else Notification.Builder(this).setContentTitle("定時神器").setContentText(text).setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(open).build()
    }
    private fun updateNotification(text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, notification(text))
    }

    override fun onDestroy() {
        tick?.let { handler.removeCallbacks(it) }
        listOfNotNull(panel, picker).forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; picker = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

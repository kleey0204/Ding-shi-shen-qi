package com.example.autoclickerpro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FloatingService : Service() {
    companion object {
        const val ACTION_SHOW = "com.example.autoclickerpro.SHOW"
        const val ACTION_PICK_POINT = "com.example.autoclickerpro.PICK_POINT"
        const val ACTION_SCHEDULE = "com.example.autoclickerpro.SCHEDULE"
        const val ACTION_FIRE = "com.example.autoclickerpro.FIRE"
        private const val CHANNEL = "scheduled_tap_v6"
        private const val NOTIFICATION_ID = 76
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var panel: View? = null
    private var picker: View? = null
    private var marker: View? = null
    private var status: TextView? = null
    private var countdown: TextView? = null
    private var tick: Runnable? = null
    private var pausedAll = false
    private val prefs by lazy { getSharedPreferences("autoclicker", Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification("定時神器：等待任務"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PICK_POINT -> showPicker()
            ACTION_SCHEDULE, ACTION_SHOW -> {
                showPanel()
                showSavedMarker()
                updateStatus()
            }
            ACTION_FIRE -> {
                showPanel()
                showSavedMarker()
                val id = intent.getLongExtra(AlarmReceiver.EXTRA_TASK_ID, -1L)
                if (id > 0L) handler.postDelayed({ fireTask(id) }, 350L)
            }
        }
        return START_STICKY
    }

    private fun params(flags: Int = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN) =
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(15, 22, 35))
        }
        box.addView(TextView(this).apply {
            text = "定時神器"; textSize = 18f; setTextColor(Color.WHITE)
        })
        status = TextView(this).apply {
            textSize = 15f; setTextColor(Color.rgb(0, 240, 150))
            text = "● 定時啟動中"
            setPadding(0, 8, 0, 4)
        }
        box.addView(status)
        countdown = TextView(this).apply {
            textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, 8)
        }
        box.addView(countdown)
        addButton(box, "暫停", 0xFF34475C.toInt()) { pauseAll() }
        addButton(box, "繼續", 0xFF17634F.toInt()) { resumeAll() }
        addButton(box, "停止", 0xFF873D45.toInt()) { stopAll() }
        addButton(box, "設定", 0xFF34475C.toInt()) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        addButton(box, "關閉", 0xFF34475C.toInt()) { closePanel() }
        panel = box
        val p = params().apply { x = 18; y = 180 }
        wm.addView(box, p)
        box.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = v.layoutParams as WindowManager.LayoutParams
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; return false }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = ox + (e.rawX - sx).toInt()
                        lp.y = oy + (e.rawY - sy).toInt()
                        wm.updateViewLayout(v, lp)
                        return false
                    }
                }
                return false
            }
        })
        startCountdown()
    }

    private fun addButton(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val control = TextView(this).apply {
            text = label; textSize = 16f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            includeFontPadding = false
            setBackgroundColor(color)
            isClickable = true; isFocusable = true
            setOnClickListener { action() }
        }
        parent.addView(control, LinearLayout.LayoutParams(-1, 44).apply { topMargin = 5 })
    }

    private fun showPicker() {
        picker?.let { return }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(Color.rgb(15, 22, 35))
        }
        val markerView = TextView(this).apply {
            text = "⊕"; textSize = 34f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(0, 145, 135))
            isClickable = true; isFocusable = true
        }
        bar.addView(markerView, LinearLayout.LayoutParams(64, 64))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 0, 0, 0) }
        actions.addView(TextView(this).apply {
            text = "拖曳準星到目標\n再按儲存"; textSize = 14f; setTextColor(Color.WHITE)
        })
        val save = pickerButton("儲存位置", 0xFF008773.toInt())
        val cancel = pickerButton("取消", 0xFF414858.toInt())
        actions.addView(save, LinearLayout.LayoutParams(-1, 44).apply { topMargin = 4 })
        actions.addView(cancel, LinearLayout.LayoutParams(-1, 40).apply { topMargin = 4 })
        bar.addView(actions, LinearLayout.LayoutParams(150, -2))
        picker = bar
        val lp = params().apply { x = 110; y = 300 }
        wm.addView(bar, lp)
        markerView.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; return true }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = ox + (e.rawX - sx).toInt()
                        lp.y = oy + (e.rawY - sy).toInt()
                        wm.updateViewLayout(bar, lp)
                        return true
                    }
                    MotionEvent.ACTION_UP -> return true
                }
                return false
            }
        })
        save.setOnClickListener {
            val x = lp.x + markerView.width / 2f
            val y = lp.y + markerView.height / 2f
            prefs.edit().putString("point", "${x.toInt()},${y.toInt()}").apply()
            removePicker()
            showSavedMarker()
            Toast.makeText(this, "已儲存座標：${x.toInt()}, ${y.toInt()}，準星會在任務期間顯示", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        cancel.setOnClickListener { removePicker() }
    }

    private fun pickerButton(label: String, color: Int) = TextView(this).apply {
        text = label; textSize = 16f; gravity = Gravity.CENTER
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        includeFontPadding = false
        setTextColor(Color.WHITE); setBackgroundColor(color)
        isClickable = true; isFocusable = true
    }

    private fun removePicker() {
        picker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        picker = null
    }

    private fun showSavedMarker() {
        val raw = prefs.getString("point", null) ?: return
        val values = raw.split(",")
        if (values.size != 2) return
        val x = values[0].toIntOrNull() ?: return
        val y = values[1].toIntOrNull() ?: return
        marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        val size = (42 * resources.displayMetrics.density).toInt()
        val cross = TextView(this).apply {
            text = "⊕"; textSize = 38f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(0, 255, 170))
            setShadowLayer(8f, 0f, 0f, Color.BLACK)
            includeFontPadding = false
        }
        marker = cross
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x - size / 2
            this.y = y - size / 2
        }
        try { wm.addView(cross, lp) } catch (_: Exception) { marker = null }
    }

    private fun pauseAll() {
        var count = 0
        TaskStore.all(this).filter { it.status == TapTask.STATUS_PENDING }.forEach {
            AlarmScheduler.cancel(this, it.id)
            TaskStore.updateStatus(this, it.id, TapTask.STATUS_PAUSED)
            count++
        }
        updateStatus()
        Toast.makeText(this, if (count > 0) "已暫停 $count 個鬧鐘" else "目前沒有可暫停的鬧鐘", Toast.LENGTH_SHORT).show()
    }

    private fun resumeAll() {
        val alarmManager = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
            Toast.makeText(this, "請先開啟精確鬧鐘權限", Toast.LENGTH_LONG).show()
            startActivity(Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        var count = 0
        TaskStore.all(this).filter { it.status == TapTask.STATUS_PAUSED && it.at > System.currentTimeMillis() }.forEach {
            TaskStore.updateStatus(this, it.id, TapTask.STATUS_PENDING)
            AlarmScheduler.schedule(this, it.copy(status = TapTask.STATUS_PENDING))
            count++
        }
        pausedAll = false
        updateStatus()
        Toast.makeText(this, if (count > 0) "已恢復 $count 個鬧鐘" else "沒有可恢復的未來鬧鐘", Toast.LENGTH_SHORT).show()
    }

    private fun stopAll() {
        AlarmScheduler.cancelAll(this)
        TaskStore.clearActive(this)
        tick?.let { handler.removeCallbacks(it) }
        removeMarker()
        closePanel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun fireTask(id: Long) {
        val task = TaskStore.all(this).firstOrNull {
            it.id == id && it.status == TapTask.STATUS_PENDING
        } ?: return
        val point = prefs.getString("point", null)?.split(",")
        val x = point?.getOrNull(0)?.toFloatOrNull()
        val y = point?.getOrNull(1)?.toFloatOrNull()
        if (x == null || y == null) {
            markFailed(id, "找不到點擊座標，請重新設定")
            return
        }
        status?.text = "● 定時啟動中"
        countdown?.text = "正在執行指定位置點擊…"
        attemptTap(id, x, y, 0)
    }

    private fun attemptTap(id: Long, x: Float, y: Float, attempt: Int) {
        val accessibility = ClickAccessibilityService.instance
        if (accessibility == null) {
            if (attempt < 10) {
                countdown?.text = "正在連線無障礙服務… ${attempt + 1}/10"
                handler.postDelayed({ attemptTap(id, x, y, attempt + 1) }, 500L)
            } else {
                markFailed(id, "無障礙服務未連線，請確認權限")
            }
            return
        }
        accessibility.tap(x, y) { success ->
            if (success) {
                TaskStore.updateStatus(this, id, TapTask.STATUS_DONE)
                status?.text = "● 點擊已完成"
                countdown?.text = "執行時間：" + SimpleDateFormat("HH:mm:ss", Locale.TAIWAN).format(Date())
                updateNotification("已完成一次點擊")
                updateStatus()
            } else {
                markFailed(id, "系統未接受點擊手勢")
            }
        }
    }

    private fun markFailed(id: Long, reason: String) {
        TaskStore.updateStatus(this, id, TapTask.STATUS_FAILED)
        status?.text = "● 點擊失敗：$reason"
        countdown?.text = "請檢查無障礙權限、目標 App 是否允許手勢"
        updateNotification("點擊失敗：$reason")
        updateStatus()
    }

    private fun updateStatus() {
        val active = TaskStore.active(this)
        val pending = active.filter { it.status == TapTask.STATUS_PENDING }
        val paused = active.filter { it.status == TapTask.STATUS_PAUSED }
        status?.text = when {
            pending.isNotEmpty() -> "● 定時啟動中"
            paused.isNotEmpty() -> "Ⅱ 定時任務已暫停"
            else -> "✓ 目前沒有等待中的任務"
        }
        val next = pending.minByOrNull { it.at } ?: paused.minByOrNull { it.at }
        countdown?.text = next?.let {
            val remain = (it.at - System.currentTimeMillis()).coerceAtLeast(0L) / 1000
            "下一個任務：" + SimpleDateFormat("MM/dd HH:mm", Locale.TAIWAN).format(it.at) +
                "  ·  倒數 %02d:%02d:%02d".format(remain / 3600, (remain % 3600) / 60, remain % 60)
        } ?: "所有任務已執行或停止"
        updateNotification(if (pending.isNotEmpty()) "定時啟動中：${pending.size} 個待執行" else if (paused.isNotEmpty()) "任務已暫停" else "目前沒有等待中的任務")
        if (pending.isEmpty() && paused.isEmpty()) removeMarker() else showSavedMarker()
    }

    private fun startCountdown() {
        tick?.let { handler.removeCallbacks(it) }
        val runnable = object : Runnable {
            override fun run() {
                if (panel != null) {
                    updateCountdownOnly()
                    handler.postDelayed(this, 1000L)
                }
            }
        }
        tick = runnable
        handler.post(runnable)
    }

    private fun updateCountdownOnly() {
        val active = TaskStore.active(this)
        val next = active.minByOrNull { it.at } ?: return
        val remain = (next.at - System.currentTimeMillis()).coerceAtLeast(0L) / 1000
        countdown?.text = "下一個任務：" + SimpleDateFormat("MM/dd HH:mm", Locale.TAIWAN).format(next.at) +
            "  ·  倒數 %02d:%02d:%02d".format(remain / 3600, (remain % 3600) / 60, remain % 60)
    }

    private fun removeMarker() {
        marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        marker = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "定時神器", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL).setContentTitle("定時神器").setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(open).setOngoing(true).build()
        } else {
            Notification.Builder(this).setContentTitle("定時神器").setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(open).setOngoing(true).build()
        }
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, notification(text))
    }

    override fun onDestroy() {
        tick?.let { handler.removeCallbacks(it) }
        listOfNotNull(panel, picker, marker).forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; picker = null; marker = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}

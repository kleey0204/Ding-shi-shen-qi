package com.example.autoclickerpro

import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 12, 20)
    private val card = Color.rgb(19, 27, 41)
    private val card2 = Color.rgb(27, 38, 55)
    private val accent = Color.rgb(0, 220, 190)
    private val muted = Color.rgb(151, 166, 187)
    private val prefs by lazy { getSharedPreferences("autoclicker", MODE_PRIVATE) }
    private var selectedAt = 0L
    private var timeLabel: TextView? = null
    private var pointLabel: TextView? = null
    private var permissionBox: LinearLayout? = null
    private var taskBox: LinearLayout? = null
    private var summaryBox: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.setBackgroundColor(bg)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 26, 20, 30)
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "定時神器"
            textSize = 29f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "SMART SCHEDULER  /  V7.0"
            textSize = 11f
            letterSpacing = .15f
            setTextColor(accent)
            setPadding(2, 3, 0, 18)
        })

        summaryBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 15, 16, 15)
            background = rounded(Color.rgb(16, 49, 47), 16)
        }
        root.addView(summaryBox)
        refreshSummary()

        root.addView(section("新增定時任務"))
        timeLabel = info("尚未選擇日期與時間")
        root.addView(timeLabel)
        addButton(root, "開啟鬧鐘管理", accent) { startActivity(Intent(this, AlarmActivity::class.java)) }
        addButton(root, "＋ 新增／管理鬧鐘", Color.rgb(0, 145, 132)) { startActivity(Intent(this, AlarmActivity::class.java)) }

        root.addView(section("點擊設定"))
        pointLabel = info("尚未設定點擊位置")
        root.addView(pointLabel)
        addButton(root, "設定螢幕點擊位置", Color.rgb(35, 76, 91)) {
            if (!Settings.canDrawOverlays(this)) requestOverlayPermission()
            else startFloating(FloatingService.ACTION_PICK_POINT)
        }
        addButton(root, "調整游標外觀", card2) { showCursorSettings() }

        root.addView(section("權限狀態"))
        permissionBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            background = rounded(card, 14)
        }
        root.addView(permissionBox)
        addButton(root, "懸浮視窗權限設定", card2) { requestOverlayPermission() }
        addButton(root, "無障礙服務設定", card2) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton(root, "開啟懸浮控制視窗", card2) {
            if (Settings.canDrawOverlays(this)) startFloating(FloatingService.ACTION_SHOW)
            else requestOverlayPermission()
        }

        root.addView(section("定時任務"))
        taskBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(taskBox)
        root.addView(TextView(this).apply {
            text = "只需設定時間；若今天所選時間已過，將自動安排至明天。所有鬧鐘共用同一個點擊座標。"
            textSize = 12f
            setTextColor(muted)
            setPadding(4, 18, 4, 0)
        })
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        refreshUi()
    }

    override fun onResume() { super.onResume(); refreshUi() }

    private fun chooseDateTime(initial: Long, onDone: (Long) -> Unit = { selectedAt = it; timeLabel?.text = "預定時間：" + fmt(it) }) {
        // 只選時分；若今天這個時間已過，安排到明天。
        val c = Calendar.getInstance().apply { if (initial > 0L) timeInMillis = initial }
        TimePickerDialog(this, { _, hour, minute ->
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
            }
            onDone(target.timeInMillis)
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
    }

    private fun addAlarm() {
        if (selectedAt <= System.currentTimeMillis()) {
            Toast.makeText(this, "請先選擇未來的日期與時間", Toast.LENGTH_SHORT).show()
            return
        }
        if (!permissionsReady()) return
        if (prefs.getString("point", null) == null) {
            Toast.makeText(this, "請先設定點擊位置", Toast.LENGTH_SHORT).show()
            return
        }
        val task = TapTask(System.currentTimeMillis(), selectedAt)
        TaskStore.add(this, task)
        AlarmScheduler.schedule(this, task)
        startFloating(FloatingService.ACTION_SCHEDULE)
        Toast.makeText(this, "已新增定時任務", Toast.LENGTH_SHORT).show()
        selectedAt = 0L
        refreshUi()
    }

    private fun permissionsReady(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "請先開啟懸浮視窗權限", Toast.LENGTH_LONG).show()
            requestOverlayPermission()
            return false
        }
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "請先啟用定時神器無障礙服務", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return false
        }
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            Toast.makeText(this, "請允許精確鬧鐘", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return false
        }
        return true
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, ClickAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun refreshUi() {
        timeLabel?.text = if (selectedAt > 0L) "預定時間：" + fmt(selectedAt) else "尚未選擇日期與時間"
        pointLabel?.text = prefs.getString("point", null)?.let { "已設定座標：$it（所有任務共用）" } ?: "尚未設定點擊位置"
        permissionBox?.removeAllViews()
        val overlay = Settings.canDrawOverlays(this)
        val access = isAccessibilityEnabled()
        val alarm = if (android.os.Build.VERSION.SDK_INT >= 31)
            (getSystemService(ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms() else true
        addPermissionLine("懸浮視窗", overlay)
        addPermissionLine("無障礙點擊服務", access)
        addPermissionLine("精確鬧鐘", alarm)

        taskBox?.removeAllViews()
        val tasks = TaskStore.all(this).sortedBy { it.at }
        if (tasks.isEmpty()) {
            taskBox?.addView(info("目前沒有定時任務"))
        } else {
            tasks.forEach { task ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(12, 10, 8, 10)
                    background = rounded(card, 12)
                }
                val text = TextView(this).apply {
                    this.text = fmt(task.at) + "\n" + statusText(task.status)
                    textSize = 14f
                    setTextColor(Color.WHITE)
                    setLineSpacing(2f, 1f)
                }
                row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(actionChip("編輯", card2) { editTask(task) })
                row.addView(actionChip("複製", Color.rgb(25, 91, 82)) { copyTask(task) })
                row.addView(actionChip("刪除", Color.rgb(112, 49, 59)) {
                    AlarmScheduler.cancel(this, task.id)
                    TaskStore.remove(this, task.id)
                    refreshUi()
                })
                taskBox?.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 7 })
            }
        }
        refreshSummary()
    }

    private fun editTask(task: TapTask) {
        chooseDateTime(task.at) { newAt ->
            if (newAt <= System.currentTimeMillis()) {
                Toast.makeText(this, "請選擇未來時間", Toast.LENGTH_SHORT).show()
                return@chooseDateTime
            }
            AlarmScheduler.cancel(this, task.id)
            TaskStore.updateTime(this, task.id, newAt)
            if (task.status == TapTask.STATUS_PENDING) {
                AlarmScheduler.schedule(this, task.copy(at = newAt))
            } else if (task.status == TapTask.STATUS_DONE || task.status == TapTask.STATUS_FAILED) {
                TaskStore.updateStatus(this, task.id, TapTask.STATUS_PENDING)
                AlarmScheduler.schedule(this, task.copy(at = newAt, status = TapTask.STATUS_PENDING))
            }
            refreshUi()
            Toast.makeText(this, "任務時間已更新", Toast.LENGTH_SHORT).show()
        }
    }

    private fun copyTask(task: TapTask) {
        chooseDateTime(task.at) { newAt ->
            if (newAt <= System.currentTimeMillis()) {
                Toast.makeText(this, "請選擇未來時間", Toast.LENGTH_SHORT).show()
                return@chooseDateTime
            }
            val copy = TapTask(System.currentTimeMillis(), newAt)
            TaskStore.add(this, copy)
            AlarmScheduler.schedule(this, copy)
            startFloating(FloatingService.ACTION_SCHEDULE)
            refreshUi()
            Toast.makeText(this, "已複製為新任務", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showCursorSettings() {
        val colors = arrayOf("青綠", "亮藍", "紫色", "黃色", "紅色", "白色")
        val values = intArrayOf(
            Color.rgb(0,255,170), Color.rgb(60,180,255), Color.rgb(190,110,255),
            Color.YELLOW, Color.RED, Color.WHITE
        )
        val current = prefs.getInt("cursor_color", values[0])
        val checked = values.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("游標顏色")
            .setSingleChoiceItems(colors, checked) { dialog, which ->
                prefs.edit().putInt("cursor_color", values[which]).apply()
                dialog.dismiss()
                chooseCursorSize()
            }.setNegativeButton("取消", null).show()
    }

    private fun chooseCursorSize() {
        val sizes = arrayOf("小（32 dp）", "中（44 dp）", "大（58 dp）", "特大（72 dp）")
        val values = intArrayOf(32, 44, 58, 72)
        val checked = values.indexOf(prefs.getInt("cursor_size_dp", 44)).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("游標大小")
            .setSingleChoiceItems(sizes, checked) { dialog, which ->
                prefs.edit().putInt("cursor_size_dp", values[which]).apply()
                dialog.dismiss()
                startFloating(FloatingService.ACTION_SHOW)
                Toast.makeText(this, "游標外觀已更新", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("完成") { _, _ ->
                startFloating(FloatingService.ACTION_SHOW)
            }.show()
    }

    private fun refreshSummary() {
        summaryBox?.removeAllViews()
        val tasks = TaskStore.all(this)
        val pending = tasks.count { it.status == TapTask.STATUS_PENDING }
        val done = tasks.count { it.status == TapTask.STATUS_DONE }
        val next = tasks.filter { it.status == TapTask.STATUS_PENDING }.minByOrNull { it.at }
        summaryBox?.addView(TextView(this).apply {
            text = if (pending > 0) "● 定時啟動中" else "● 任務待命"
            textSize = 15f; setTextColor(accent); typeface = Typeface.DEFAULT_BOLD
        })
        summaryBox?.addView(TextView(this).apply {
            text = next?.let { fmt(it.at) } ?: "尚無等待中的任務"
            textSize = 22f; setTextColor(Color.WHITE); setPadding(0, 6, 0, 3)
        })
        summaryBox?.addView(TextView(this).apply {
            text = "全部 ${tasks.size}　·　等待 $pending　·　完成 $done"
            textSize = 12f; setTextColor(Color.rgb(174, 201, 198))
        })
    }

    private fun addPermissionLine(label: String, enabled: Boolean) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply {
            text = "●"; textSize = 18f
            setTextColor(if (enabled) Color.rgb(0, 230, 130) else Color.rgb(240, 75, 85))
            setPadding(0, 3, 12, 3)
        })
        row.addView(TextView(this).apply {
            text = "$label  ${if (enabled) "已開啟" else "尚未開啟"}"
            textSize = 14f
            setTextColor(if (enabled) Color.WHITE else Color.rgb(255, 145, 145))
            setPadding(0, 5, 0, 5)
        })
        permissionBox?.addView(row)
    }

    private fun actionChip(label: String, color: Int, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 11f; gravity = Gravity.CENTER
        setTextColor(Color.WHITE); setPadding(8, 10, 8, 10)
        background = rounded(color, 8)
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-2, -2).apply { leftMargin = 4 }
        layoutParams = lp
    }

    private fun statusText(status: String) = when (status) {
        TapTask.STATUS_PENDING -> "● 等待執行"
        TapTask.STATUS_PAUSED -> "Ⅱ 已暫停"
        TapTask.STATUS_DONE -> "✓ 已完成"
        TapTask.STATUS_FAILED -> "! 執行失敗"
        else -> status
    }

    private fun startFloating(action: String) {
        val i = Intent(this, FloatingService::class.java).setAction(action)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun requestOverlayPermission() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun fmt(at: Long) = SimpleDateFormat("HH:mm", Locale.TAIWAN).format(at)
    private fun info(text: String) = TextView(this).apply {
        this.text = text; textSize = 13f; setTextColor(muted)
        setPadding(13, 13, 13, 13); background = rounded(card, 12)
    }
    private fun section(text: String) = TextView(this).apply {
        this.text = text; textSize = 16f; setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD; setPadding(2, 20, 0, 9)
    }
    private fun addButton(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val b = TextView(this).apply {
            text = label; textSize = 15f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            includeFontPadding = false
            background = rounded(color, 12)
            isClickable = true; isFocusable = true
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(-1, 48).apply { topMargin = 7 })
    }
    private fun rounded(color: Int, radius: Int) =
        GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
}

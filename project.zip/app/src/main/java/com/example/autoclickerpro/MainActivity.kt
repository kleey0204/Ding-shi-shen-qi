package com.example.autoclickerpro

import android.app.Activity
import android.app.AlarmManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 12, 20)
    private val card = Color.rgb(19, 27, 41)
    private val accent = Color.rgb(0, 220, 190)
    private val prefs by lazy { getSharedPreferences("autoclicker", MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var pointStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(30), dp(24), dp(30))
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "定時神器"
            textSize = 32f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "ONE TAP  •  SMART SCHEDULER"
            textSize = 11f
            letterSpacing = .16f
            setTextColor(accent)
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, dp(30))
        })
        status = TextView(this).apply {
            text = "● 待命中"
            textSize = 16f
            setTextColor(accent)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(15), dp(12), dp(15))
            background = rounded(Color.rgb(16, 49, 47), 14)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(24) })

        actionButton(root, "啟動", accent) { startAutomation() }
        actionButton(root, "暫停", Color.rgb(47, 76, 103)) { sendService(FloatingService.ACTION_PAUSE) }
        actionButton(root, "設定時間", card) {
            startActivity(Intent(this, AlarmActivity::class.java))
        }
        actionButton(root, "點擊位置設定", card) {
            if (!Settings.canDrawOverlays(this)) requestOverlayPermission()
            else sendService(FloatingService.ACTION_PICK_POINT)
        }

        pointStatus = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(151, 166, 187))
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        }
        root.addView(pointStatus)
        setContentView(root)
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun startAutomation() {
        if (!permissionsReady()) return
        if (prefs.getString("point", null) == null) {
            Toast.makeText(this, "請先設定點擊位置", Toast.LENGTH_LONG).show()
            sendService(FloatingService.ACTION_PICK_POINT)
            return
        }
        val tasks = TaskStore.all(this)
        if (tasks.none { it.status == TapTask.STATUS_PENDING }) {
            Toast.makeText(this, "請先到設定時間新增並開啟鬧鐘", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, AlarmActivity::class.java))
            return
        }
        sendService(FloatingService.ACTION_START)
        Toast.makeText(this, "定時神器已啟動", Toast.LENGTH_SHORT).show()
        moveTaskToBack(true)
    }

    private fun permissionsReady(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "請先開啟懸浮視窗權限", Toast.LENGTH_LONG).show()
            requestOverlayPermission()
            return false
        }
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "請先啟用定時神器無障礙服務", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return false
        }
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            Toast.makeText(this, "請允許精確鬧鐘", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return false
        }
        return true
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, ClickAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun refreshStatus() {
        val running = prefs.getBoolean("automation_running", false)
        val pending = TaskStore.all(this).count { it.status == TapTask.STATUS_PENDING }
        val paused = TaskStore.all(this).count { it.status == TapTask.STATUS_PAUSED }
        status.text = when {
            running && pending > 0 -> "● 定時啟動中 · $pending 個鬧鐘"
            paused > 0 || !running && pending > 0 -> "Ⅱ 已待命 · $pending 個鬧鐘"
            else -> "● 待命中"
        }
        pointStatus.text = prefs.getString("point", null)?.let { "點擊位置已設定：$it" } ?: "尚未設定點擊位置"
    }

    private fun sendService(action: String) {
        val i = Intent(this, FloatingService::class.java).setAction(action)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun requestOverlayPermission() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun actionButton(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val button = TextView(this).apply {
            text = label
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(color, 16)
            isClickable = true
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(13) })
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}

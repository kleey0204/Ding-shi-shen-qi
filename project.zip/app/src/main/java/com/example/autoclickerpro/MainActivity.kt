package com.example.autoclickerpro

import android.app.Activity
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 13, 22)
    private val card = Color.rgb(22, 28, 43)
    private val accent = Color.rgb(0, 220, 190)
    private val prefs by lazy { getSharedPreferences("autoclicker", MODE_PRIVATE) }
    private var selectedAt = 0L
    private var timeLabel: TextView? = null
    private var pointLabel: TextView? = null
    private var permissionBox: LinearLayout? = null
    private var taskBox: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 30, 22, 24)
            setBackgroundColor(bg)
        }
        content.addView(TextView(this).apply {
            text = "定時神器"; textSize = 30f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        })
        content.addView(TextView(this).apply {
            text = "MULTI ALARM  •  ONE TAP"; textSize = 12f; letterSpacing = .12f
            setTextColor(accent); setPadding(0, 4, 0, 18)
        })
        content.addView(info("可建立多個鬧鐘任務。每個任務到時間後，會在同一個已儲存的螢幕座標點擊一次。"))
        content.addView(section("新增定時任務"))
        timeLabel = info("尚未選擇時間")
        content.addView(timeLabel)
        addButton(content, "選擇日期與時間", accent) { chooseDateTime() }
        pointLabel = info("尚未設定點擊位置")
        content.addView(section("共用點擊位置"))
        content.addView(pointLabel)
        addButton(content, "設定螢幕點擊位置", Color.rgb(0, 145, 135)) {
            if (!Settings.canDrawOverlays(this)) requestOverlayPermission()
            else startFloating(FloatingService.ACTION_PICK_POINT)
        }
        addButton(content, "新增這個鬧鐘", accent) { addAlarm() }

        content.addView(section("權限狀態"))
        permissionBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            background = rounded(card, 14)
        }
        content.addView(permissionBox)
        addButton(content, "前往懸浮視窗權限", Color.rgb(48, 58, 78)) { requestOverlayPermission() }
        addButton(content, "前往無障礙服務設定", Color.rgb(48, 58, 78)) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton(content, "開啟懸浮控制視窗", Color.rgb(48, 58, 78)) {
            if (Settings.canDrawOverlays(this)) startFloating(FloatingService.ACTION_SHOW)
            else requestOverlayPermission()
        }

        content.addView(section("已建立的鬧鐘"))
        taskBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(taskBox)
        content.addView(TextView(this).apply {
            text = "提示：所有鬧鐘共用同一個點擊座標。啟動後會顯示「定時啟動中」及定位準星。若目標 App 禁止自動化操作，點擊仍可能被阻擋。"
            textSize = 12f; setTextColor(Color.rgb(145, 158, 178)); setPadding(4, 18, 4, 0)
        })

        val scroll = ScrollView(this).apply { addView(content) }
        setContentView(scroll)
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun chooseDateTime() {
        val now = Calendar.getInstance()
        val c = Calendar.getInstance().apply {
            if (selectedAt > 0L) timeInMillis = selectedAt
        }
        DatePickerDialog(this, { _, year, month, day ->
            TimePickerDialog(this, { _, hour, minute ->
                selectedAt = Calendar.getInstance().apply {
                    set(year, month, day, hour, minute, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                timeLabel?.text = "預定時間：" + fmt(selectedAt)
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun addAlarm() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "請先開啟懸浮視窗權限", Toast.LENGTH_LONG).show()
            requestOverlayPermission()
            return
        }
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "請先啟用「定時神器」無障礙服務", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        if (android.os.Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
            Toast.makeText(this, "請允許精確鬧鐘", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return
        }
        if (selectedAt <= System.currentTimeMillis()) {
            Toast.makeText(this, "請選擇未來的日期與時間", Toast.LENGTH_SHORT).show()
            return
        }
        if (prefs.getString("point", null) == null) {
            Toast.makeText(this, "請先設定點擊位置", Toast.LENGTH_SHORT).show()
            return
        }

        val task = TapTask(System.currentTimeMillis(), selectedAt)
        TaskStore.add(this, task)
        AlarmScheduler.schedule(this, task)
        startFloating(FloatingService.ACTION_SCHEDULE)
        Toast.makeText(this, "鬧鐘已新增，定時任務已啟動", Toast.LENGTH_LONG).show()
        selectedAt = 0L
        refreshUi()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, ClickAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun refreshUi() {
        selectedAt = selectedAt.takeIf { it > 0L } ?: 0L
        timeLabel?.text = if (selectedAt > 0L) "預定時間：" + fmt(selectedAt) else "請先選擇要新增的鬧鐘時間"
        val p = prefs.getString("point", null)
        pointLabel?.text = if (p != null) "已設定座標：$p（所有鬧鐘共用）" else "尚未設定點擊位置"
        permissionBox?.removeAllViews()
        val overlay = Settings.canDrawOverlays(this)
        val access = isAccessibilityEnabled()
        val alarm = if (android.os.Build.VERSION.SDK_INT >= 31) {
            (getSystemService(ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
        } else true
        addPermissionLine(permissionBox!!, "懸浮視窗", overlay)
        addPermissionLine(permissionBox!!, "無障礙點擊服務", access)
        addPermissionLine(permissionBox!!, "精確鬧鐘", alarm)

        taskBox?.removeAllViews()
        val tasks = TaskStore.all(this).sortedBy { it.at }
        if (tasks.isEmpty()) {
            taskBox?.addView(info("目前沒有鬧鐘任務"))
        } else {
            tasks.forEach { task ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(12, 10, 8, 10)
                    background = rounded(card, 12)
                }
                val label = TextView(this).apply {
                    text = "${fmt(task.at)}\n${statusText(task.status)}"
                    textSize = 15f; setTextColor(Color.WHITE)
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                }
                row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
                val remove = TextView(this).apply {
                    text = "刪除"; textSize = 14f; gravity = Gravity.CENTER
                    setTextColor(Color.WHITE); setPadding(18, 12, 18, 12)
                    background = rounded(Color.rgb(130, 55, 65), 10)
                    setOnClickListener {
                        AlarmScheduler.cancel(this@MainActivity, task.id)
                        TaskStore.remove(this@MainActivity, task.id)
                        refreshUi()
                    }
                }
                row.addView(remove)
                taskBox?.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
            }
        }
    }

    private fun statusText(status: String) = when (status) {
        TapTask.STATUS_PENDING -> "● 等待執行"
        TapTask.STATUS_PAUSED -> "Ⅱ 已暫停"
        TapTask.STATUS_DONE -> "✓ 已完成"
        TapTask.STATUS_FAILED -> "! 點擊失敗，請檢查權限"
        else -> status
    }

    private fun addPermissionLine(parent: LinearLayout, label: String, enabled: Boolean) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply {
            text = if (enabled) "●" else "●"
            textSize = 18f
            setTextColor(if (enabled) Color.rgb(0, 230, 130) else Color.rgb(235, 75, 75))
            setPadding(0, 3, 12, 3)
        })
        row.addView(TextView(this).apply {
            text = "$label：${if (enabled) "已開啟" else "尚未開啟"}"
            textSize = 15f; setTextColor(if (enabled) Color.WHITE else Color.rgb(255, 145, 145))
            setPadding(0, 5, 0, 5)
        })
        parent.addView(row)
    }

    private fun startFloating(action: String) {
        val i = Intent(this, FloatingService::class.java).setAction(action)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun requestOverlayPermission() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun fmt(at: Long) = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.TAIWAN).format(at)

    private fun info(text: String) = TextView(this).apply {
        this.text = text; textSize = 15f; setTextColor(Color.LTGRAY)
        setPadding(16, 16, 16, 16); background = rounded(card, 14)
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text; textSize = 17f; setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD; setPadding(2, 22, 0, 10)
    }

    private fun addButton(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val b = TextView(this).apply {
            text = label; textSize = 16f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            includeFontPadding = false
            background = rounded(color, 14)
            isClickable = true; isFocusable = true
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 8 })
    }

    private fun rounded(color: Int, radius: Int) =
        GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
}

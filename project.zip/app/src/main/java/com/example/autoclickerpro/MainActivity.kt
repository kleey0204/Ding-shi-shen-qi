package com.example.autoclickerpro

import android.app.Activity
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 13, 22)
    private val card = Color.rgb(22, 28, 43)
    private val accent = Color.rgb(0, 220, 190)
    private val prefs by lazy { getSharedPreferences("autoclicker", MODE_PRIVATE) }
    private var scheduledAt = 0L
    private var timeLabel: TextView? = null
    private var pointLabel: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(26, 38, 26, 26)
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "定時神器"; textSize = 30f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "ONE TAP  •  SMART SCHEDULER"; textSize = 11f; letterSpacing = .15f
            setTextColor(accent); setPadding(0, 4, 0, 24)
        })
        root.addView(TextView(this).apply {
            text = "設定一次點擊，時間到了自動執行。啟動後可透過懸浮視窗暫停、繼續或停止。"
            textSize = 14f; setTextColor(Color.LTGRAY); setPadding(18, 18, 18, 18)
            background = rounded(card, 18)
        })
        root.addView(section("執行時間"))
        timeLabel = TextView(this).apply {
            textSize = 18f; setTextColor(Color.WHITE); setPadding(18, 18, 18, 18)
            background = rounded(card, 14)
        }
        root.addView(timeLabel)
        addButton(root, "選擇日期與時間", accent) { chooseDateTime() }
        root.addView(section("點擊位置"))
        pointLabel = TextView(this).apply {
            textSize = 14f; setTextColor(Color.LTGRAY); setPadding(18, 18, 18, 18)
            background = rounded(card, 14)
        }
        root.addView(pointLabel)
        addButton(root, "設定螢幕點擊位置", Color.rgb(0, 145, 135)) {
            if (!Settings.canDrawOverlays(this)) requestOverlayPermission()
            else startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_PICK_POINT))
        }
        root.addView(section("必要權限"))
        addButton(root, "允許懸浮視窗", Color.rgb(48, 58, 78)) { requestOverlayPermission() }
        addButton(root, "啟用無障礙點擊服務", Color.rgb(48, 58, 78)) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton(root, "啟動定時任務", accent) { scheduleTask() }
        addButton(root, "開啟懸浮控制視窗", Color.rgb(48, 58, 78)) {
            if (Settings.canDrawOverlays(this)) startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_SHOW))
            else requestOverlayPermission()
        }
        root.addView(TextView(this).apply {
            text = "注意：需允許懸浮視窗及無障礙服務。部分遊戲、影音或金融 App 可能限制自動點擊。"
            textSize = 12f; setTextColor(Color.rgb(145, 158, 178)); setPadding(4, 20, 4, 0)
        })
        setContentView(root)
        refreshLabels()
    }

    override fun onResume() { super.onResume(); refreshLabels() }

    private fun chooseDateTime() {
        val c = Calendar.getInstance().apply { if (scheduledAt > 0) timeInMillis = scheduledAt }
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, min ->
                val chosen = Calendar.getInstance().apply { set(y, m, d, h, min, 0); set(Calendar.MILLISECOND, 0) }
                scheduledAt = chosen.timeInMillis
                prefs.edit().putLong("scheduled_at", scheduledAt).apply()
                refreshLabels()
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun scheduleTask() {
        if (!Settings.canDrawOverlays(this)) { requestOverlayPermission(); return }
        if (ClickAccessibilityService.instance == null) {
            Toast.makeText(this, "請先啟用無障礙服務，再返回 App", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
        }
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        if (android.os.Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
            Toast.makeText(this, "請允許精確鬧鐘，才能準時執行", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return
        }
        val savedTime = prefs.getLong("scheduled_at", 0L).takeIf { it > 0 } ?: scheduledAt
        if (savedTime <= System.currentTimeMillis()) {
            Toast.makeText(this, "請設定一個未來的時間", Toast.LENGTH_SHORT).show(); return
        }
        if (prefs.getString("point", null) == null) {
            Toast.makeText(this, "請先設定點擊位置", Toast.LENGTH_SHORT).show(); return
        }
        AlarmScheduler.schedule(this, savedTime)
        startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_SCHEDULE))
        Toast.makeText(this, "已啟動定時任務", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun requestOverlayPermission() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun refreshLabels() {
        scheduledAt = prefs.getLong("scheduled_at", scheduledAt)
        timeLabel?.text = if (scheduledAt > 0) "預定時間：" + SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.TAIWAN).format(scheduledAt) else "尚未選擇時間"
        val p = prefs.getString("point", null)
        pointLabel?.text = if (p != null) "已設定點擊座標：$p" else "尚未設定點擊位置"
    }

    private fun section(text: String): TextView = TextView(this).apply {
        this.text = text; textSize = 16f; setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD; setPadding(2, 24, 0, 10)
    }
    private fun addButton(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        // Use TextView instead of the platform Button widget: some tablet themes apply
        // an unexpectedly small button text appearance to CJK glyphs.
        val b = TextView(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            includeFontPadding = false
            background = rounded(color, 14)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 9 })
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
}

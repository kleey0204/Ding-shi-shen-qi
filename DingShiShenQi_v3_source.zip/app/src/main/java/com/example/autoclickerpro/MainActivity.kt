package com.example.autoclickerpro

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 13, 22)
    private val card = Color.rgb(22, 28, 43)
    private val accent = Color.rgb(0, 220, 190)
    private val muted = Color.rgb(155, 169, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(bg)
        }

        root.addView(TextView(this).apply {
            text = "定時神器"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "AUTO TAP  •  SMART SCHEDULER"
            textSize = 11f
            letterSpacing = 0.16f
            setTextColor(accent)
            setPadding(0, 4, 0, 22)
        })

        val intro = TextView(this).apply {
            text = "精準設定點擊位置、速度與循環次數。\\n啟動懸浮控制球後，即可在其他 App 使用。"
            textSize = 15f
            setTextColor(muted)
            setPadding(18, 18, 18, 18)
            background = rounded(card, 18)
        }
        root.addView(intro)

        root.addView(TextView(this).apply {
            text = "快速設定"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(2, 26, 0, 10)
        })

        addAction(root, "01  懸浮視窗權限", "允許控制球顯示在其他 App 上層") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        addAction(root, "02  無障礙服務", "允許依照指定座標執行點擊手勢") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addAction(root, "03  啟動控制球", "前往目標 App 開始使用") {
            if (Settings.canDrawOverlays(this)) startService(Intent(this, FloatingService::class.java))
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        root.addView(TextView(this).apply {
            text = "提示：首次使用請先完成前兩項授權。部分 App 可能限制自動化操作。"
            textSize = 12f
            setTextColor(muted)
            setPadding(4, 22, 4, 0)
        })
        setContentView(root)
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }

    private fun addAction(parent: LinearLayout, title: String, subtitle: String, action: () -> Unit) {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 15, 18, 15)
            background = rounded(card, 16)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        item.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        item.addView(TextView(this).apply {
            text = subtitle
            textSize = 12f
            setTextColor(muted)
            setPadding(0, 5, 0, 0)
        })
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 }
        parent.addView(item, lp)
    }
}

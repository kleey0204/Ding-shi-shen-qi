package com.example.autoclickerpro

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

data class TapPoint(val x: Float, val y: Float)

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var bubble: View? = null
    private var panel: View? = null
    private var picker: View? = null
    private val points = mutableListOf<TapPoint>()
    private var running = false
    private var paused = false
    private var intervalMs = 250L
    private var roundsLimit = 0
    private var startDelayMs = 0L
    private var durationLimitMs = 0L
    private var round = 0
    private var clickCount = 0
    private var pointIndex = 0
    private var runStartedAt = 0L
    private var intervalInput: EditText? = null
    private var roundsInput: EditText? = null
    private var delayInput: EditText? = null
    private var durationInput: EditText? = null
    private var status: TextView? = null
    private var pointsLabel: TextView? = null

    private val clickTask = object : Runnable {
        override fun run() {
            if (!running || paused) return
            if (durationLimitMs > 0 && SystemClock.elapsedRealtime() - runStartedAt >= durationLimitMs) {
                stopClicks("已達執行時間上限")
                return
            }
            val service = ClickAccessibilityService.instance
            if (service == null) {
                stopClicks("請先啟用無障礙服務")
                Toast.makeText(this@FloatingService, "請先啟用本 App 的無障礙服務", Toast.LENGTH_LONG).show()
                return
            }
            if (points.isEmpty()) {
                stopClicks("尚未設定點擊位置")
                return
            }
            val p = points[pointIndex]
            service.tap(p.x, p.y)
            clickCount++
            pointIndex++
            if (pointIndex >= points.size) {
                pointIndex = 0
                round++
                if (roundsLimit > 0 && round >= roundsLimit) {
                    stopClicks("已完成 $round 圈")
                    return
                }
            }
            refreshStatus()
            handler.postDelayed(this, intervalMs)
        }
    }

    private val delayedStart = Runnable {
        if (running && !paused) {
            runStartedAt = SystemClock.elapsedRealtime()
            handler.removeCallbacks(clickTask)
            handler.post(clickTask)
            refreshStatus("執行中")
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        loadPoints()
        showBubble()
    }

    private fun overlayParams() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun showBubble() {
        val b = Button(this).apply {
            text = "點"
            textSize = 17f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(0, 170, 155))
            setOnClickListener { showPanel() }
            setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    val lp = v.layoutParams as WindowManager.LayoutParams
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                            return false
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                            if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 12) moved = true
                            if (moved) { lp.x = startX + dx; lp.y = startY + dy; wm.updateViewLayout(v, lp) }
                            return moved
                        }
                        MotionEvent.ACTION_UP -> return moved
                    }
                    return false
                }
            })
        }
        bubble = b
        val p = overlayParams().apply { x = 24; y = 260 }
        wm.addView(b, p)
    }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 16)
            setBackgroundColor(Color.rgb(17, 23, 36))
        }
        box.addView(TextView(this).apply { text = "定時神器"; textSize = 21f; setTextColor(Color.WHITE) })
        status = TextView(this).apply { setTextColor(Color.rgb(175, 190, 210)); textSize = 14f }
        box.addView(status)
        pointsLabel = TextView(this).apply { setTextColor(Color.rgb(175, 190, 210)); textSize = 14f }
        box.addView(pointsLabel)
        box.addView(Button(this).apply { setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(0, 135, 125)); text = "＋ 新增點擊位置"; setOnClickListener { closePanel(); showPicker() } })
        box.addView(Button(this).apply { setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(48, 58, 78)); text = "移除最後一個位置"; setOnClickListener {
            if (points.isNotEmpty()) points.removeAt(points.lastIndex)
            savePoints(); refreshStatus()
        } })
        intervalInput = field("點擊間隔毫秒（至少 80）", intervalMs.toString()).also { box.addView(it) }
        roundsInput = field("循環圈數（0 = 無限）", roundsLimit.toString()).also { box.addView(it) }
        delayInput = field("開始前延遲秒數", "0").also { box.addView(it) }
        durationInput = field("執行時間上限分鐘（0 = 不限）", "0").also { box.addView(it) }
        box.addView(Button(this).apply { setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(0, 150, 125)); text = "▶ 開始"; setOnClickListener { startClicks() } })
        box.addView(Button(this).apply { setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(55, 75, 110)); text = "Ⅱ 暫停／繼續"; setOnClickListener { togglePause() } })
        box.addView(Button(this).apply { setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(150, 55, 70)); text = "■ 停止"; setOnClickListener { stopClicks("已手動停止") } })
        box.addView(Button(this).apply { setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(48, 58, 78)); text = "關閉面板"; setOnClickListener { closePanel() } })
        panel = box
        val p = overlayParams().apply { x = 24; y = 320; flags = 0 }
        wm.addView(box, p)
        refreshStatus()
    }

    private fun field(hintText: String, value: String) = EditText(this).apply {
        hint = hintText
        setText(value)
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(135, 150, 170))
        setBackgroundColor(Color.rgb(31, 40, 58))
        inputType = 2
        textSize = 14f
    }

    private fun showPicker() {
        val capture = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0x22000000)
            addView(TextView(this@FloatingService).apply {
                text = "點一下螢幕要點擊的位置；選好後會自動加入"
                textSize = 18f
                setTextColor(Color.WHITE)
                setPadding(24, 48, 24, 24)
                setBackgroundColor(0xEE101827.toInt())
            })
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_UP) {
                    points.add(TapPoint(event.rawX, event.rawY))
                    savePoints()
                    picker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
                    picker = null
                    Toast.makeText(this@FloatingService, "已新增位置 ${points.size}", Toast.LENGTH_SHORT).show()
                    showPanel()
                }
                true
            }
        }
        picker = capture
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(capture, p)
    }

    private fun startClicks() {
        if (ClickAccessibilityService.instance == null) {
            Toast.makeText(this, "請先到設定啟用無障礙服務", Toast.LENGTH_LONG).show()
            return
        }
        if (points.isEmpty()) {
            Toast.makeText(this, "請先新增至少一個點擊位置", Toast.LENGTH_SHORT).show()
            return
        }
        intervalMs = (intervalInput?.text?.toString()?.toLongOrNull() ?: 250L).coerceAtLeast(80L)
        roundsLimit = (roundsInput?.text?.toString()?.toIntOrNull() ?: 0).coerceAtLeast(0)
        startDelayMs = ((delayInput?.text?.toString()?.toLongOrNull() ?: 0L).coerceAtLeast(0L)) * 1000
        durationLimitMs = ((durationInput?.text?.toString()?.toLongOrNull() ?: 0L).coerceAtLeast(0L)) * 60_000
        running = true
        paused = false
        round = 0
        clickCount = 0
        pointIndex = 0
        handler.removeCallbacks(clickTask)
        handler.removeCallbacks(delayedStart)
        if (startDelayMs > 0) {
            refreshStatus("等待開始")
            handler.postDelayed(delayedStart, startDelayMs)
        } else {
            runStartedAt = SystemClock.elapsedRealtime()
            handler.post(clickTask)
            refreshStatus("執行中")
        }
    }

    private fun togglePause() {
        if (!running) { startClicks(); return }
        if (paused) {
            paused = false
            runStartedAt = SystemClock.elapsedRealtime()
            handler.post(clickTask)
            refreshStatus("執行中")
        } else {
            paused = true
            handler.removeCallbacks(clickTask)
            handler.removeCallbacks(delayedStart)
            refreshStatus("已暫停")
        }
    }

    private fun stopClicks(message: String) {
        running = false
        paused = false
        handler.removeCallbacks(clickTask)
        handler.removeCallbacks(delayedStart)
        refreshStatus(message)
    }

    private fun refreshStatus(prefix: String = if (running) "執行中" else "待機中") {
        status?.text = "$prefix｜已點擊 $clickCount 次｜第 ${round + 1} 圈"
        pointsLabel?.text = "已設定 ${points.size} 個位置：" + points.mapIndexed { i, p -> "\n${i + 1}. X=${p.x.toInt()}，Y=${p.y.toInt()}" }.joinToString("")
    }

    private fun savePoints() {
        val packed = points.joinToString(";") { "${it.x},${it.y}" }
        getSharedPreferences("autoclicker", Context.MODE_PRIVATE).edit().putString("points", packed).apply()
    }

    private fun loadPoints() {
        val packed = getSharedPreferences("autoclicker", Context.MODE_PRIVATE).getString("points", "") ?: ""
        if (packed.isNotBlank()) {
            packed.split(";").forEach { item ->
                val xy = item.split(",")
                if (xy.size == 2) {
                    val px = xy[0].toFloatOrNull()
                    val py = xy[1].toFloatOrNull()
                    if (px != null && py != null) points.add(TapPoint(px, py))
                }
            }
        }
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    override fun onDestroy() {
        stopClicks("服務已關閉")
        listOfNotNull(panel, picker, bubble).forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; picker = null; bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
